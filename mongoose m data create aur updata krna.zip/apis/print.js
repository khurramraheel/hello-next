export default {
    printBill:()=>{

        
    }
}