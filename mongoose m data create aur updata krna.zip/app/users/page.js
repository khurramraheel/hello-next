"use client";

import axios from "axios"
import { useEffect, useState } from "react"

export default()=>{

    let [users, setUsers] = useState([])

    useEffect(function(){

        axios.get('/api/signup').then(function(resp){
            console.log(resp.data)
            setUsers(resp.data.users)
        })

    }, [])

    return <div>
        <table border={1}>
            <thead>
                <tr>Email</tr>
                <tr>Password</tr>
            </thead>
            {
                users.map(function(user){
                    return <tr>
                        <td>{user._id}</td>
                        <td>{user.user_email}</td>
                        <td>{user.user_password}</td>
                        <td>
                            <button onClick={()=>{

                                // query param
                                axios.delete('/api/signup?d='+user._id)

                            }}>DELETE</button>
                        </td>
                    </tr>
                })
            }
        </table>
    </div>

}