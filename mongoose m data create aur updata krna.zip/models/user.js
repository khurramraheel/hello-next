import mongoose, { mongo } from "mongoose";

let userSchema = mongoose.Schema({
    user_email:String,
    user_name:String,
    user_password:String,
    ads:[]
})



export let User = mongoose.models.user ||  mongoose.model('user', userSchema)


// class User{
//     user_name
//     user_password
//     city
// }

// let u1 = new User();
// u1.user_name = 'ali';
// u1.user_password=343;
// u1.city = "FSD";
// u1.save();

// let u2 = new User();
// u2.user_name = "asdasd";
// u2.user_password = 343;
// u2.city = "sdasd"
// u2.save();




// ORM-objcet Relational Mapper
