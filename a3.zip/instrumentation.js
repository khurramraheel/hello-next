import { connectKaro } from "./app/lib/db";

export function register(){

    connectKaro()

}