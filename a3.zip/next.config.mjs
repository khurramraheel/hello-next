/** @type {import('next').NextConfig} */
const nextConfig = {
    experimental:{
        instrumentationHook:true
    }
};

export default nextConfig;
