import { NextResponse } from "next/server";


export async function GET(req){

    // request ka answer back krna
    return NextResponse.json({a:30})

}

export async function POST(req){

    // incoming data pakarna
    let data = await req.json();
    console.log(data);

    console.log('code chal gya wa')

    // request ka answer back krna
    return NextResponse.json({
        name:"ali"
    });

}