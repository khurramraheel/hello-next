import { dbConnectKaro } from "./app/lib/db";


export function register(){

    dbConnectKaro();

    

}